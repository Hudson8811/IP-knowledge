<?php
/**
 * Theme bootstrap for IP Knowledge.
 *
 * Long-form legal copy is maintained in the normal WordPress editor. ACF
 * controls the surrounding presentation data: hero, cards, sidebar, files and contacts.
 */
defined( 'ABSPATH' ) || exit;

function ipk_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
}
add_action( 'after_setup_theme', 'ipk_setup' );

function ipk_enqueue_assets() {
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'ip-knowledge', get_stylesheet_uri(), array(), $version );
	wp_enqueue_script( 'ip-knowledge-menu', get_theme_file_uri( 'assets/js/article-menu.js' ), array(), $version, true );
}
add_action( 'wp_enqueue_scripts', 'ipk_enqueue_assets' );

function ipk_asset( $path ) {
	return get_theme_file_uri( 'assets/' . ltrim( $path, '/' ) );
}

function ipk_current_language() {
	return function_exists( 'pll_current_language' ) ? pll_current_language( 'slug' ) : 'zh';
}

function ipk_language_url( $language ) {
	return function_exists( 'pll_home_url' ) ? pll_home_url( $language ) : ( 'en' === $language ? home_url( '/en/' ) : home_url( '/' ) );
}

function ipk_translation_url( $post_id, $language ) {
	if ( function_exists( 'pll_get_post' ) ) {
		$translation_id = pll_get_post( $post_id, $language );
		if ( $translation_id ) {
			return get_permalink( $translation_id );
		}
	}
	return get_permalink( $post_id );
}

function ipk_field( $field_name, $post_id = false, $default = '' ) {
	$value = function_exists( 'get_field' ) ? get_field( $field_name, $post_id ) : get_post_meta( $post_id ?: get_the_ID(), $field_name, true );
	return ( null === $value || false === $value || '' === $value ) ? $default : $value;
}

function ipk_copy( $key ) {
	$language = ipk_current_language();
	$copy     = array(
		'zh' => array(
			'home_label' => '法律知识中心首页', 'articles' => '文章', 'all_articles' => '全部文章', 'open_menu' => '打开文章菜单', 'close_menu' => '关闭文章菜单', 'switch_to' => '切换至', 'pdf' => 'PDF', 'contacts' => '联系我们', 'footer_hub' => '/ 法律知识中心', 'footer_tagline' => '俄罗斯复杂投资项目的首选律师事务所', 'about' => '关于我们', 'privacy' => '隐私政策', 'cookies' => 'Cookie 政策', 'read_more' => '阅读全文', 'firm_name' => '伊万扬与合伙人律师事务所（俄罗斯）',
		),
		'en' => array(
			'home_label' => 'Knowledge hub home', 'articles' => 'articles', 'all_articles' => 'all articles', 'open_menu' => 'Open article menu', 'close_menu' => 'Close article menu', 'switch_to' => 'switch to', 'pdf' => 'PDF', 'contacts' => 'contacts', 'footer_hub' => '/ knowledge hub', 'footer_tagline' => 'first choice law firm for complex investments in Russia', 'about' => 'about us', 'privacy' => 'privacy policy', 'cookies' => 'cookies policy', 'read_more' => 'read full article', 'firm_name' => 'Ivanyan and Partners (Russia)',
		),
	);
	return isset( $copy[ $language ][ $key ] ) ? $copy[ $language ][ $key ] : $copy['en'][ $key ];
}

function ipk_register_acf_fields() {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) { return; }
	acf_add_local_field_group( array(
		'key' => 'group_ipk_home', 'title' => 'Knowledge Hub — home page', 'position' => 'normal', 'style' => 'seamless',
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'page' ) ) ),
		'fields' => array(
			array( 'key' => 'field_ipk_hero_title', 'label' => 'Hero title', 'name' => 'hero_title', 'type' => 'text', 'required' => 1 ),
			array( 'key' => 'field_ipk_hero_subtitle', 'label' => 'Hero subtitle', 'name' => 'hero_subtitle', 'type' => 'text' ),
			array( 'key' => 'field_ipk_hero_description', 'label' => 'Hero description (desktop)', 'name' => 'hero_description', 'type' => 'wysiwyg', 'tabs' => 'visual', 'media_upload' => 0 ),
			array( 'key' => 'field_ipk_hero_mobile', 'label' => 'Hero description (mobile)', 'name' => 'hero_description_mobile', 'type' => 'textarea', 'rows' => 3 ),
			array( 'key' => 'field_ipk_hero_link', 'label' => 'Hero article', 'name' => 'hero_link', 'type' => 'post_object', 'post_type' => array( 'post' ), 'return_format' => 'id', 'ui' => 1 ),
			array( 'key' => 'field_ipk_cards', 'label' => 'Article cards', 'name' => 'home_cards', 'type' => 'repeater', 'layout' => 'block', 'button_label' => 'Add article card', 'sub_fields' => array(
				array( 'key' => 'field_ipk_card_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text', 'required' => 1 ),
				array( 'key' => 'field_ipk_card_description', 'label' => 'Description', 'name' => 'description', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_ipk_card_icon', 'label' => 'Icon', 'name' => 'icon', 'type' => 'image', 'return_format' => 'id', 'preview_size' => 'thumbnail' ),
				array( 'key' => 'field_ipk_card_article', 'label' => 'Article', 'name' => 'article', 'type' => 'post_object', 'post_type' => array( 'post' ), 'return_format' => 'id', 'ui' => 1 ),
			) ),
		),
	) );
	acf_add_local_field_group( array(
		'key' => 'group_ipk_article', 'title' => 'Knowledge Hub — article settings', 'position' => 'normal', 'style' => 'seamless',
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'post' ) ) ),
		'fields' => array(
			array( 'key' => 'field_ipk_sidebar_title', 'label' => 'Sidebar title', 'name' => 'sidebar_title', 'type' => 'textarea', 'rows' => 2 ),
			array( 'key' => 'field_ipk_sidebar_intro', 'label' => 'Sidebar intro', 'name' => 'sidebar_intro', 'type' => 'textarea', 'rows' => 4 ),
			array( 'key' => 'field_ipk_pdf_url', 'label' => 'PDF URL', 'name' => 'pdf_url', 'type' => 'url' ),
			array( 'key' => 'field_ipk_contacts', 'label' => 'Contacts', 'name' => 'article_contacts', 'type' => 'repeater', 'layout' => 'table', 'button_label' => 'Add contact', 'sub_fields' => array(
				array( 'key' => 'field_ipk_contact_name', 'label' => 'Name', 'name' => 'name', 'type' => 'text', 'required' => 1 ),
				array( 'key' => 'field_ipk_contact_role', 'label' => 'Role', 'name' => 'role', 'type' => 'text' ),
				array( 'key' => 'field_ipk_contact_photo', 'label' => 'Photo', 'name' => 'photo', 'type' => 'image', 'return_format' => 'id', 'preview_size' => 'thumbnail' ),
				array( 'key' => 'field_ipk_contact_link', 'label' => 'Profile URL', 'name' => 'profile_url', 'type' => 'url' ),
				array( 'key' => 'field_ipk_contact_email', 'label' => 'Email', 'name' => 'email', 'type' => 'email' ),
				array( 'key' => 'field_ipk_contact_phone', 'label' => 'Phone', 'name' => 'phone', 'type' => 'text' ),
			) ),
		),
	) );
}
add_action( 'acf/init', 'ipk_register_acf_fields' );

function ipk_seed_post( $postarr ) {
	$existing = get_page_by_path( $postarr['post_name'], OBJECT, $postarr['post_type'] );
	return $existing ? (int) $existing->ID : (int) wp_insert_post( $postarr );
}

function ipk_article_html( $file ) {
	$path = get_theme_file_path( 'data/' . $file );
	if ( ! file_exists( $path ) ) { return ''; }
	return wp_kses_post( str_replace( 'assets/img/', get_theme_file_uri( 'assets/img/' ), (string) file_get_contents( $path ) ) );
}

function ipk_seed_initial_content() {
	if ( get_option( 'ipk_content_seeded' ) || ! function_exists( 'pll_set_post_language' ) ) { return; }
	$home_zh = ipk_seed_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => '法律知识中心', 'post_name' => 'home', 'post_content' => '' ) );
	$home_en = ipk_seed_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Knowledge hub', 'post_name' => 'knowledge-hub', 'post_content' => '' ) );
	$guide = ipk_seed_post( array( 'post_type' => 'post', 'post_status' => 'publish', 'post_title' => 'Doing Business in Russia 2026', 'post_name' => 'doing-business-russia-2026', 'post_content' => ipk_article_html( 'doing-business.html' ) ) );
	$currency = ipk_seed_post( array( 'post_type' => 'post', 'post_status' => 'publish', 'post_title' => 'Currency Control in Russia 2026', 'post_name' => 'currency-control-russia-2026', 'post_content' => ipk_article_html( 'currency-control.html' ) ) );
	pll_set_post_language( $home_zh, 'zh' ); pll_set_post_language( $home_en, 'en' ); pll_set_post_language( $guide, 'en' ); pll_set_post_language( $currency, 'en' );
	pll_save_post_translations( array( 'zh' => $home_zh, 'en' => $home_en ) );
	update_option( 'show_on_front', 'page' ); update_option( 'page_on_front', $home_zh );
	$zh_cards = array(
		array( 'title' => '外汇管制', 'description' => '俄罗斯的外汇管制法规历来复杂且严格，规则繁多，违规行为可能受到严厉处罚。', 'icon' => 0, 'article' => $currency ),
		array( 'title' => '数据保护', 'description' => '俄罗斯的数据保护与隐私基本原则及监管框架，与中国、欧盟或美国等地区存在显著差异。', 'icon' => 0, 'article' => $currency ),
		array( 'title' => '制裁', 'description' => '俄罗斯的制裁和反制裁制度持续变化，交易结构需要提前评估。', 'icon' => 0, 'article' => $guide ),
		array( 'title' => '劳动关系', 'description' => '进入俄罗斯市场时，劳动关系与移民合规需要同步规划。', 'icon' => 0, 'article' => $guide ),
		array( 'title' => '税务', 'description' => '投资结构与业务模式应提前考虑俄罗斯税务规则。', 'icon' => 0, 'article' => $guide ),
		array( 'title' => '争议解决', 'description' => '合同安排应明确适用法律、争议解决方式及执行风险。', 'icon' => 0, 'article' => $guide ),
	);
	$en_cards = array(
		array( 'title' => 'Currency control', 'description' => 'Russian currency control regulations have historically been both complicated and strict, with complex rules and severe penalties for non-compliance.', 'icon' => 0, 'article' => $currency ),
		array( 'title' => 'Data protection', 'description' => 'Russia’s general data protection and privacy principles and regulatory framework differ substantially from the PRC, EU and US.', 'icon' => 0, 'article' => $currency ),
		array( 'title' => 'Sanctions', 'description' => 'Counter-sanctions and restrictions require a careful review of the parties and the transaction structure.', 'icon' => 0, 'article' => $guide ),
		array( 'title' => 'Employment', 'description' => 'Employment and immigration compliance should be planned alongside the market-entry strategy.', 'icon' => 0, 'article' => $guide ),
		array( 'title' => 'Tax', 'description' => 'Russian tax rules should be considered early when choosing the investment structure and business model.', 'icon' => 0, 'article' => $guide ),
		array( 'title' => 'Dispute resolution', 'description' => 'Contracts should address governing law, dispute resolution and enforcement risk from the outset.', 'icon' => 0, 'article' => $guide ),
	);
	if ( function_exists( 'update_field' ) ) {
		update_field( 'field_ipk_hero_title', "2026年\n俄罗斯营商指南", $home_zh ); update_field( 'field_ipk_hero_subtitle', '中国企业法律指南', $home_zh ); update_field( 'field_ipk_hero_description', '<strong>俄罗斯经济韧性强</strong>、自然资源丰富，消费市场不断增长。西方品牌的退出为<strong>中国企业</strong>拓展业务带来了难得机遇，涉及消费品、电子商务、科技、基础设施和能源等多个领域。', $home_zh ); update_field( 'field_ipk_hero_mobile', '概述中国企业与俄罗斯开展业务及在俄经营时需要关注的主要法律问题', $home_zh ); update_field( 'field_ipk_hero_link', $guide, $home_zh ); update_field( 'field_ipk_cards', $zh_cards, $home_zh );
		update_field( 'field_ipk_hero_title', "Doing Business\nin Russia 2026", $home_en ); update_field( 'field_ipk_hero_subtitle', 'A Legal Guide for Chinese Enterprises', $home_en ); update_field( 'field_ipk_hero_description', '<strong>Russia enjoys</strong> a resilient economy, abundant natural resources and a growing consumer market. Withdrawal by Western brands has opened up a rare opportunity for <strong>Chinese companies</strong> to expand into sectors ranging from consumer goods and e-commerce to technology, infrastructure and energy.', $home_en ); update_field( 'field_ipk_hero_mobile', 'A general overview of the key legal considerations for Chinese companies dealing with Russia and doing business in the country.', $home_en ); update_field( 'field_ipk_hero_link', $guide, $home_en ); update_field( 'field_ipk_cards', $en_cards, $home_en );
		foreach ( array( $guide, $currency ) as $article_id ) {
			update_field( 'field_ipk_sidebar_title', get_the_title( $article_id ), $article_id ); update_field( 'field_ipk_sidebar_intro', 'General Overview by|Nikolay Simoyanov /counsel|Mark Rovinskiy /partner', $article_id );
			update_field( 'field_ipk_contacts', array(
				array( 'name' => 'nikolay simoyanov', 'role' => 'counsel', 'photo' => 0, 'profile_url' => 'https://ivanyan.partners/en/people/NikolaySimoyanov/', 'email' => 'n.simoyanov@iplf.ru', 'phone' => '+7 495 647 0046' ),
				array( 'name' => 'mark rovinskiy', 'role' => 'partner', 'photo' => 0, 'profile_url' => 'https://ivanyan.partners/en/people/MarkRovinskiy/', 'email' => 'm.rovinskiy@iplf.ru', 'phone' => '+7 495 647 0046' ),
			), $article_id );
		}
	}
	update_option( 'ipk_content_seeded', 1, false );
}
add_action( 'admin_init', 'ipk_seed_initial_content' );

function ipk_fix_article_links( $content ) {
	if ( ! is_singular( 'post' ) ) { return $content; }
	$currency = get_page_by_path( 'currency-control-russia-2026', OBJECT, 'post' );
	if ( $currency ) {
		$content = str_replace( 'href="currency-control.html"', 'href="' . esc_url( get_permalink( $currency ) ) . '"', $content );
	}
	return $content;
}
add_filter( 'the_content', 'ipk_fix_article_links', 20 );
